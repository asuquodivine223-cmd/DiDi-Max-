package com.didimax.app

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Gold = Color(0xFFF3C75F)
private val Purple = Color(0xFF8B5CF6)
private val Blue = Color(0xFF1687FF)
private val Dark = Color(0xFF050505)
private val Panel = Color(0xFF121212)
private val Muted = Color(0xFF9A9A9A)

enum class Screen { Welcome, Home, Videos, Photos, Games, VideoEditor, PhotoEditor, Game, Settings, About }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DiDiMaxApp(this) }
    }
}

@Composable
fun DiDiMaxApp(context: Context) {
    var screen by remember { mutableStateOf(Screen.Welcome) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedGame by remember { mutableStateOf("Tap Challenge") }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) { selectedUri = uri; screen = Screen.PhotoEditor } }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) { selectedUri = uri; screen = Screen.VideoEditor } }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Dark, surface = Panel, primary = Gold
    )) {
        Surface(Modifier.fillMaxSize(), color = Dark) {
            when (screen) {
                Screen.Welcome -> WelcomeScreen { screen = Screen.Home }
                Screen.Home -> MainShell("Home", screen, { screen = it }, selectedUri)
                Screen.Videos -> MainShell("Videos", screen, { screen = it }, selectedUri)
                Screen.Photos -> MainShell("Photos", screen, { screen = it }, selectedUri)
                Screen.Games -> MainShell("Games", screen, { screen = it }, selectedUri)
                Screen.VideoEditor -> VideoEditorScreen(
                    uri = selectedUri,
                    onBack = { screen = Screen.Videos },
                    onPick = { videoPicker.launch("video/*") }
                )
                Screen.PhotoEditor -> PhotoEditorScreen(
                    context = context,
                    uri = selectedUri,
                    onBack = { screen = Screen.Photos },
                    onPick = { photoPicker.launch("image/*") }
                )
                Screen.Game -> GameScreen(selectedGame) { screen = Screen.Games }
                Screen.Settings -> SettingsScreen(
                    onBack = { screen = Screen.Home },
                    onAbout = { screen = Screen.About }
                )
                Screen.About -> AboutScreen { screen = Screen.Settings }
            }
        }
    }
}

@Composable
fun MainShell(
    title: String,
    current: Screen,
    navigate: (Screen) -> Unit,
    selectedUri: Uri?
) {
    Scaffold(
        containerColor = Dark,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF090909)) {
                val items = listOf(
                    Triple("Home", "⌂", Screen.Home),
                    Triple("Videos", "▶", Screen.Videos),
                    Triple("Photos", "▧", Screen.Photos),
                    Triple("Games", "🎮", Screen.Games)
                )
                items.forEach { (name, icon, destination) ->
                    NavigationBarItem(
                        selected = current == destination,
                        onClick = { navigate(destination) },
                        icon = { Text(icon, fontSize = 20.sp) },
                        label = { Text(name, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold, selectedTextColor = Gold,
                            unselectedIconColor = Muted, unselectedTextColor = Muted,
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (current) {
                Screen.Home -> HomeScreen(
                    onVideos = { navigate(Screen.Videos) },
                    onPhotos = { navigate(Screen.Photos) },
                    onGames = { navigate(Screen.Games) },
                    onSettings = { navigate(Screen.Settings) }
                )
                Screen.Videos -> VideosScreen(
                    onEditor = { navigate(Screen.VideoEditor) }
                )
                Screen.Photos -> PhotosScreen(
                    onEditor = { navigate(Screen.PhotoEditor) }
                )
                Screen.Games -> GamesScreen(
                    onGame = { game -> selectedGame = game; navigate(Screen.Game) }
                )
                else -> HomeScreen({}, {}, {})
            }
        }
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color(0xFF34230A), Color.Black, Color.Black))
        ).padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("♛", color = Gold, fontSize = 72.sp)
            Text("DiDi Max", color = Gold, fontSize = 42.sp, fontWeight = FontWeight.Bold)
            Text("Create  •  Edit  •  Play", color = Gold)
            Spacer(Modifier.height(28.dp))
            Text(
                "Turn your ideas into amazing\nvideos, perfect photos and\nendless fun.",
                color = Color.LightGray, textAlign = TextAlign.Center, lineHeight = 24.sp
            )
            Spacer(Modifier.height(65.dp))
            Button(
                onClick = onStart,
                Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(30.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold)
            ) { Text("Get Started  →", color = Color.Black, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(16.dp))
            Text("I already have an account", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun Header(onSettings: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(20.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("♛ DiDi Max", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("⌕   ⚙", color = Color.White, fontSize = 24.sp, modifier = Modifier.clickable { onSettings() })
    }
}

@Composable
fun HomeScreen(onVideos: () -> Unit, onPhotos: () -> Unit, onGames: () -> Unit, onSettings: () -> Unit = {}) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(onSettings)
        Text("Welcome Back", color = Muted, modifier = Modifier.padding(horizontal = 24.dp))
        Text("Create. Edit. Play.", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
        Text("Your all-in-one creative and gaming hub.", color = Muted, modifier = Modifier.padding(horizontal = 24.dp))
        Spacer(Modifier.height(18.dp))
        Row(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Feature("▣", "Make Videos", "Shoot • Edit • Share", Gold, Modifier.weight(1f), onVideos)
            Feature("▧", "Edit Photos", "Enhance • Filter • Create", Purple, Modifier.weight(1f), onPhotos)
            Feature("🎮", "Play Games", "Compete • Win", Blue, Modifier.weight(1f), onGames)
        }
        SectionTitle("Trending Now")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MiniCard("Video Templates", "Make it epic", "🌆")
            MiniCard("Photo Filters", "Glow up your pic", "✨")
            MiniCard("Top Games", "Play now", "🎮")
        }
        SectionTitle("Quick Access")
        Text("Your creations will appear here.", color = Muted, modifier = Modifier.padding(horizontal = 24.dp))
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun Feature(icon: String, title: String, subtitle: String, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }.height(160.dp), colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(13.dp)) {
            Text(icon, color = accent, fontSize = 29.sp)
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp)
            Spacer(Modifier.height(12.dp))
            Text("→", color = accent, fontSize = 23.sp, modifier = Modifier.align(Alignment.End))
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp), Arrangement.SpaceBetween) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text("See All", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun MiniCard(title: String, sub: String, art: String) {
    Card(Modifier.width(138.dp).height(145.dp), colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp)) {
            Box(Modifier.fillMaxWidth().height(82.dp).background(Color(0xFF222222), RoundedCornerShape(10.dp)), Alignment.Center) {
                Text(art, fontSize = 38.sp)
            }
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
            Text(sub, color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (onBack != null) "‹" else " ", color = Color.White, fontSize = 34.sp,
            modifier = Modifier.clickable(enabled = onBack != null) { onBack?.invoke() })
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Text("♛", color = Gold, fontSize = 20.sp)
    }
}

@Composable
fun VideosScreen(onEditor: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Make Videos")
        Hero("Turn Moments\nInto Masterpieces", "Create stunning videos with easy-to-use tools.", "Start Creating  →", onEditor)
        SectionTitle("Popular Templates")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MiniCard("Cinematic", "Template", "🌆"); MiniCard("Birthday", "Template", "🎈"); MiniCard("Travel", "Template", "🏝️")
        }
        SectionTitle("Editing Tools")
        ToolGrid(listOf("✂" to "Trim", "✦" to "Effects", "●" to "Filters", "♫" to "Music", "T" to "Text", "☺" to "Stickers"))
    }
}

@Composable
fun PhotosScreen(onEditor: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Edit Photos")
        Hero("Make Every Photo\nStand Out", "Enhance, filter and create polished images.", "Start Editing  →", onEditor)
        SectionTitle("Photo Tools")
        ToolGrid(listOf("✦" to "Enhance", "◉" to "Filters", "✂" to "Crop", "☀" to "Light", "T" to "Text", "◇" to "Frames"))
    }
}

@Composable
fun GamesScreen(onGame: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Games")
        Hero("Play. Relax. Win.", "Discover games, challenge your skills and have fun.", "Explore All  →") {}
        SectionTitle("Featured Games")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GameCard("Tap Challenge", "Arcade", "⚡") { onGame("Tap Challenge") }
            GameCard("Memory Match", "Puzzle", "🧠") { onGame("Memory Match") }
            GameCard("Tic Tac Toe", "Strategy", "⭕") { onGame("Tic Tac Toe") }
        }
        SectionTitle("Categories")
        ToolGrid(listOf("⚔" to "Action", "◉" to "Racing", "✚" to "Puzzle", "🏆" to "Sports", "🎮" to "Arcade", "▲" to "Adventure"))
    }
}

@Composable
fun GameCard(title: String, sub: String, art: String, onClick: () -> Unit) {
    Card(Modifier.width(138.dp).height(150.dp).clickable { onClick() }, colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp)) {
            Box(Modifier.fillMaxWidth().height(82.dp).background(Color(0xFF102040), RoundedCornerShape(10.dp)), Alignment.Center) {
                Text(art, fontSize = 40.sp)
            }
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
            Text(sub, color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
fun Hero(title: String, subtitle: String, button: String, onClick: () -> Unit) {
    Card(Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(205.dp),
        colors = CardDefaults.cardColors(Color(0xFF171717)), shape = RoundedCornerShape(18.dp)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF282828), Color(0xFF0A0A0A)))).padding(18.dp)) {
            Column(Modifier.align(Alignment.CenterStart)) {
                Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                Text(subtitle, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.width(230.dp))
                Spacer(Modifier.height(16.dp))
                Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(24.dp)) {
                    Text(button, color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ToolGrid(items: List<Pair<String, String>>) {
    Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (icon, label) ->
                    Card(Modifier.weight(1f).height(86.dp).clickable { }, colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxSize(), Alignment.CenterHorizontally, Arrangement.Center) {
                            Text(icon, color = Gold, fontSize = 24.sp)
                            Text(label, color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onAbout: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Settings", onBack)
        SettingsRow("👤", "Account", "Sign-in and profile")
        SettingsRow("☁", "Cloud Storage", "Coming with backend connection")
        SettingsRow("🔔", "Notifications", "App notification preferences")
        SettingsRow("💎", "Premium", "Ad-free and premium creative tools")
        SettingsRow("🔒", "Privacy", "Privacy controls and permissions")
        SettingsRow("ℹ", "About DiDi Max", "Version 1.0.0", onClick = onAbout)
        Spacer(Modifier.height(20.dp))
        Text(
            "DiDi Max is a creative and gaming app. Features that connect to online services require their respective production accounts and backend configuration.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(24.dp)
        )
    }
}

@Composable
fun SettingsRow(icon: String, title: String, subtitle: String, onClick: () -> Unit = {}) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(Panel), shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 23.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
            Text("›", color = Gold, fontSize = 25.sp)
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("About DiDi Max", onBack)
        Text("♛", color = Gold, fontSize = 70.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("DiDi Max", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("Create • Edit • Play", color = Color.LightGray, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(28.dp))
        Text("Version 1.0.0", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(30.dp))
        Text("Production checklist", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp))
        listOf(
            "Video Cut/Trim export",
            "Photo filters and editing UI",
            "Starter games",
            "Camera/gallery import",
            "Account/settings screens"
        ).forEach {
            Text("✓  $it", color = Color.LightGray, modifier = Modifier.padding(horizontal = 28.dp, vertical = 7.dp))
        }
        Spacer(Modifier.height(25.dp))
        Text("Online accounts, cloud sync, advertising, payments, and a larger game/content catalogue need service credentials and backend infrastructure before release.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(24.dp))
    }
}

@Composable
fun VideoEditorScreen(uri: Uri?, onBack: () -> Unit, onPick: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var startMs by remember { mutableStateOf(0L) }
    var endMs by remember { mutableStateOf(30_000L) }
    var durationMs by remember { mutableStateOf(30_000L) }
    var exporting by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(uri) {
        if (uri != null) {
            durationMs = withContext(Dispatchers.IO) {
                try {
                    val extractor = MediaExtractor()
                    extractor.setDataSource(context, uri, null)
                    var d = 30_000L
                    for (i in 0 until extractor.trackCount) {
                        val f = extractor.getTrackFormat(i)
                        if (f.containsKey(MediaFormat.KEY_DURATION)) {
                            d = max(d, f.getLong(MediaFormat.KEY_DURATION) / 1000L)
                        }
                    }
                    extractor.release()
                    d
                } catch (_: Exception) { 30_000L }
            }
            endMs = durationMs
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Video Editor", onBack)

        Box(
            Modifier.padding(18.dp).fillMaxWidth().height(220.dp)
                .background(Color(0xFF101010), RoundedCornerShape(18.dp)),
            Alignment.Center
        ) {
            Text(
                if (uri == null) "Choose a video to start trimming"
                else "Video loaded ✓\n${formatTime(startMs)}  →  ${formatTime(endMs)}",
                color = Color.White, textAlign = TextAlign.Center, lineHeight = 25.sp
            )
        }

        Row(
            Modifier.padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onPick,
                colors = ButtonDefaults.buttonColors(containerColor = Gold)
            ) { Text("Choose Video", color = Color.Black) }

            OutlinedButton(
                enabled = uri != null && !exporting && endMs > startMs,
                onClick = {
                    if (uri != null) {
                        exporting = true
                        message = "Cutting video…"
                        CoroutineScope(Dispatchers.Main).launch {
                            val result = withContext(Dispatchers.IO) {
                                trimVideo(context, uri, startMs, endMs)
                            }
                            exporting = false
                            message = result
                        }
                    }
                }
            ) { Text(if (exporting) "Working…" else "Save Cut") }
        }

        SectionTitle("Cut / Trim")
        Text(
            "Start: ${formatTime(startMs)}",
            color = Color.White,
            modifier = Modifier.padding(horizontal = 22.dp)
        )
        Slider(
            value = startMs.toFloat().coerceIn(0f, durationMs.toFloat()),
            onValueChange = { startMs = min(it.toLong(), max(0L, endMs - 500L)) },
            valueRange = 0f..durationMs.toFloat(),
            modifier = Modifier.padding(horizontal = 18.dp)
        )

        Text(
            "End: ${formatTime(endMs)}",
            color = Color.White,
            modifier = Modifier.padding(horizontal = 22.dp)
        )
        Slider(
            value = endMs.toFloat().coerceIn(0f, durationMs.toFloat()),
            onValueChange = { endMs = max(it.toLong(), min(durationMs, startMs + 500L)) },
            valueRange = 0f..durationMs.toFloat(),
            modifier = Modifier.padding(horizontal = 18.dp)
        )

        Text(
            "Selected length: ${formatTime(max(0L, endMs - startMs))}",
            color = Gold,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp)
        )

        if (message.isNotEmpty()) {
            Text(
                message,
                color = if (message.startsWith("Saved")) Gold else Color.LightGray,
                modifier = Modifier.padding(22.dp)
            )
        }

        SectionTitle("Other Editing Tools")
        ToolGrid(
            listOf(
                "✦" to "Effects", "●" to "Filters", "♫" to "Music",
                "T" to "Text", "☺" to "Stickers", "↺" to "Rotate"
            )
        )
        Spacer(Modifier.height(20.dp))
    }
}

private fun formatTime(ms: Long): String {
    val total = max(0L, ms) / 1000L
    val minutes = total / 60L
    val seconds = total % 60L
    return "%02d:%02d".format(minutes, seconds)
}

/**
 * Cuts the selected time range from a video using Android's MediaExtractor/MediaMuxer.
 * It copies the original encoded samples, so no re-encoding is required.
 */
private fun trimVideo(
    context: Context,
    inputUri: Uri,
    startMs: Long,
    endMs: Long
): String {
    val extractor = MediaExtractor()
    return try {
        extractor.setDataSource(context, inputUri, null)

        val output = File(context.cacheDir, "didimax_cut_${System.currentTimeMillis()}.mp4")
        if (output.exists()) output.delete()

        val muxer = MediaMuxer(
            output.absolutePath,
            MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        )

        val trackMap = mutableMapOf<Int, Int>()
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                trackMap[i] = muxer.addTrack(format)
            }
        }

        if (trackMap.isEmpty()) {
            muxer.release()
            return "No audio/video track was found."
        }

        muxer.start()
        val buffer = java.nio.ByteBuffer.allocate(1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()

        for ((sourceTrack, muxTrack) in trackMap) {
            extractor.selectTrack(sourceTrack)
            extractor.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            while (true) {
                val sampleTime = extractor.sampleTime
                if (sampleTime < 0L || sampleTime > endMs * 1000L) break

                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break

                info.offset = 0
                info.size = size
                info.presentationTimeUs = max(0L, sampleTime - startMs * 1000L)
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(muxTrack, buffer, info)
                extractor.advance()
            }
            extractor.unselectTrack(sourceTrack)
        }

        muxer.stop()
        muxer.release()
        extractor.release()

        val saved = saveToMovies(context, output)
        output.delete()

        if (saved) "Saved trimmed video to Movies/DiDi Max."
        else "Trim completed, but Android could not save it to the Movies folder."
    } catch (e: Exception) {
        try { extractor.release() } catch (_: Exception) {}
        "Trim failed: ${e.message ?: "unknown error"}"
    }
}

private fun saveToMovies(context: Context, source: File): Boolean {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "DiDiMax_Cut_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/DiDi Max")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { input -> input.copyTo(out) }
            } ?: return false
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } else {
            // On older Android versions, keep the finished file in app cache
            // rather than requesting broad legacy storage permission.
            true
        }
    } catch (_: Exception) {
        false
    }
}
@Composable
fun PhotoEditorScreen(context: Context, uri: Uri?, onBack: () -> Unit, onPick: () -> Unit) {
    var imageBitmap by remember { mutableStateOf<ImageBitmap?>(null) }
    var filter by remember { mutableStateOf("Original") }

    LaunchedEffect(uri) {
        if (uri != null) {
            imageBitmap = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
            }
        }
    }

    val colorFilter = when (filter) {
        "Warm" -> ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
            1.15f,0f,0f,0f,15f, 0f,1.0f,0f,0f,0f, 0f,0f,0.85f,0f,0f, 0f,0f,0f,1f,0f
        )))
        "Mono" -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
        else -> null
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("Photo Editor", onBack)
        Box(Modifier.padding(18.dp).fillMaxWidth().height(320.dp).background(Color(0xFF101010), RoundedCornerShape(18.dp)), Alignment.Center) {
            if (imageBitmap != null) {
                androidx.compose.foundation.Image(
                    bitmap = imageBitmap!!, contentDescription = "Selected photo",
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    contentScale = ContentScale.Fit, colorFilter = colorFilter
                )
            } else Text("Choose a photo to begin", color = Muted)
        }
        Row(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onPick, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Choose Photo", color = Color.Black) }
            OutlinedButton(onClick = {}) { Text("Save") }
        }
        SectionTitle("Filters")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Original", "Warm", "Mono").forEach { name ->
                FilterChip(selected = filter == name, onClick = { filter = name }, label = { Text(name) })
            }
        }
        SectionTitle("Editing Tools")
        ToolGrid(listOf("✦" to "Enhance", "✂" to "Crop", "☀" to "Light", "T" to "Text", "◇" to "Frames", "◉" to "Blur"))
    }
}

@Composable
fun GameScreen(game: String, onBack: () -> Unit) {
    var score by remember { mutableStateOf(0) }
    var moves by remember { mutableStateOf(0) }
    var cells by remember { mutableStateOf(List(9) { "" }) }
    var xTurn by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize()) {
        TopBar(game, onBack)
        when (game) {
            "Tap Challenge" -> {
                Text("Tap as fast as you can!", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(30.dp))
                Button(
                    onClick = { score++ },
                    Modifier.align(Alignment.CenterHorizontally).size(210.dp),
                    shape = RoundedCornerShape(105.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold)
                ) { Text("TAP!\n$score", color = Color.Black, fontSize = 28.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold) }
            }
            "Memory Match" -> {
                Text("A simple starter memory game.", color = Muted, modifier = Modifier.padding(20.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.padding(20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(listOf("★","◆","●","▲","★","◆","●","▲")) { item ->
                        Card(Modifier.height(80.dp).clickable { moves++ }, colors = CardDefaults.cardColors(Color(0xFF1A1A1A))) {
                            Box(Modifier.fillMaxSize(), Alignment.Center) { Text(item, color = Gold, fontSize = 28.sp) }
                        }
                    }
                }
                Text("Moves: $moves", color = Color.White, modifier = Modifier.padding(horizontal = 20.dp))
            }
            else -> {
                Text("Tap a square to play.", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(20.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.padding(20.dp), userScrollEnabled = false) {
                    items(cells) { cell ->
                        Card(Modifier.padding(5.dp).height(100.dp).clickable {
                            val i = cells.indexOf(cell)
                            if (i >= 0 && cells[i].isEmpty()) {
                                val copy = cells.toMutableList()
                                copy[i] = if (xTurn) "X" else "O"
                                cells = copy
                                xTurn = !xTurn
                            }
                        }, colors = CardDefaults.cardColors(Color(0xFF151515))) {
                            Box(Modifier.fillMaxSize(), Alignment.Center) { Text(cell, color = Gold, fontSize = 36.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                Text(if (xTurn) "X's turn" else "O's turn", color = Color.White, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}
